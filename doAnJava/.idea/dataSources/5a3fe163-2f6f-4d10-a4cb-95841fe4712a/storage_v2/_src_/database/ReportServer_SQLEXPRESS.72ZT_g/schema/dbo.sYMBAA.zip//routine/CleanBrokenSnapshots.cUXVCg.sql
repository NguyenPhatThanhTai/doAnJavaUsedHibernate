
CREATE PROCEDURE [dbo].[CleanBrokenSnapshots]
@Machine nvarchar(512),
@SnapshotsCleaned int OUTPUT,
@ChunksCleaned int OUTPUT,
@TempSnapshotID uniqueidentifier OUTPUT
AS
    SET DEADLOCK_PRIORITY LOW
    DECLARE @now AS datetime
    SELECT @now = GETDATE()
    
    CREATE TABLE #tempSnapshot (SnapshotDataID uniqueidentifier)
    INSERT INTO #tempSnapshot SELECT TOP 1 SnapshotDataID 
    FROM SnapshotData  WITH (NOLOCK) 
    where SnapshotData.PermanentRefcount <= 0 
    AND ExpirationDate < @now
    SET @SnapshotsCleaned = @@ROWCOUNT

    DELETE ChunkData FROM ChunkData INNER JOIN #tempSnapshot
    ON ChunkData.SnapshotDataID = #tempSnapshot.SnapshotDataID
    SET @ChunksCleaned = @@ROWCOUNT

    DELETE SnapshotData FROM SnapshotData INNER JOIN #tempSnapshot
    ON SnapshotData.SnapshotDataID = #tempSnapshot.SnapshotDataID
    
    TRUNCATE TABLE #tempSnapshot

    INSERT INTO #tempSnapshot SELECT TOP 1 SnapshotDataID 
    FROM [ReportServer$SQLEXPRESSTempDB].dbo.SnapshotData  WITH (NOLOCK) 
    where [ReportServer$SQLEXPRESSTempDB].dbo.SnapshotData.PermanentRefcount <= 0 
    AND [ReportServer$SQLEXPRESSTempDB].dbo.SnapshotData.ExpirationDate < @now
    AND [ReportServer$SQLEXPRESSTempDB].dbo.SnapshotData.Machine = @Machine
    SET @SnapshotsCleaned = @SnapshotsCleaned + @@ROWCOUNT

    SELECT @TempSnapshotID = (SELECT SnapshotDataID FROM #tempSnapshot)

    DELETE [ReportServer$SQLEXPRESSTempDB].dbo.ChunkData FROM [ReportServer$SQLEXPRESSTempDB].dbo.ChunkData INNER JOIN #tempSnapshot
    ON [ReportServer$SQLEXPRESSTempDB].dbo.ChunkData.SnapshotDataID = #tempSnapshot.SnapshotDataID
    SET @ChunksCleaned = @ChunksCleaned + @@ROWCOUNT

    DELETE [ReportServer$SQLEXPRESSTempDB].dbo.SnapshotData FROM [ReportServer$SQLEXPRESSTempDB].dbo.SnapshotData INNER JOIN #tempSnapshot
    ON [ReportServer$SQLEXPRESSTempDB].dbo.SnapshotData.SnapshotDataID = #tempSnapshot.SnapshotDataID
go

