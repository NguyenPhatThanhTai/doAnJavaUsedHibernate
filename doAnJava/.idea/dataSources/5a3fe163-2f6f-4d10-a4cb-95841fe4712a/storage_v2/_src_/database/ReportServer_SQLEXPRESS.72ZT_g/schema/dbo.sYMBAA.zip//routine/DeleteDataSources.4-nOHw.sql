
CREATE PROCEDURE [dbo].[DeleteDataSources]
@ItemID [uniqueidentifier]
AS

DELETE
FROM [DataSource]
WHERE [ItemID] = @ItemID or [SubscriptionID] = @ItemID 
DELETE
FROM [ReportServer$SQLEXPRESSTempDB].dbo.TempDataSources
WHERE [ItemID] = @ItemID
go

