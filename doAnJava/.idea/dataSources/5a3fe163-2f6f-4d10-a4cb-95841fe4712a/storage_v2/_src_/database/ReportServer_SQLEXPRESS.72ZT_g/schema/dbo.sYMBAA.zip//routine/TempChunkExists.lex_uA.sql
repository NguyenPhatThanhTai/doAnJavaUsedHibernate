
CREATE PROC [dbo].[TempChunkExists]
	@ChunkId uniqueidentifier
AS
BEGIN
	SELECT COUNT(1) FROM [ReportServer$SQLEXPRESSTempDB].dbo.SegmentedChunk
	WHERE ChunkId = @ChunkId
END
go

