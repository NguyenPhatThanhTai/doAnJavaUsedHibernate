
CREATE PROCEDURE autoadmin_metadata_query_task_agent_global_data
        @schema_version          INT,
        @task_agent_guid         UNIQUEIDENTIFIER,
        @task_agent_data         XML OUTPUT
AS
    IF (@schema_version IS NULL) OR (@task_agent_guid IS NULL)
    BEGIN
        RAISERROR ('All parameters must be specified and non-NULL. Cannot complete task agent global metadata query', -- Message text.
                   17, -- Severity,
                   1); -- State
        RETURN
    END

    SET NOCOUNT ON

    SELECT @task_agent_data = aatam.task_agent_data FROM autoadmin_task_agent_metadata aatam
    WHERE aatam.task_agent_guid = @task_agent_guid AND aatam.autoadmin_id = 0
go

